# test environment variables
